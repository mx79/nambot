__title__ = 'frtk'
__description__ = 'frtk - Package used to access to Natural Language Processing common methods: ' \
                  'stopwords, stemming, entity extraction, intent classification.'
__version__ = '0.1.0'
__author__ = 'Max Lesage'
__author_email__ = 'lesage.max@sfr.fr'
__license__ = 'None'
__url__ = 'https://github.com/mx79/frtk'
