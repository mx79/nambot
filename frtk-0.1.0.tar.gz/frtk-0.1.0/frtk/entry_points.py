import requests
from os import remove
from sys import argv
from zipfile import ZipFile


def main() -> None:
    """
    Main package entry point.

    Delegates to other functions based on user input.
    """
    try:
        user_cmd = argv[1]
        if user_cmd == 'install':
            install_template_from_github()
        else:
            RuntimeError('please supply a command for frtk - e.g. install.')
    except IndexError:
        RuntimeError('please supply a command for frtk - e.g. install.')

    return None


def install_template_from_github() -> None:
    """
    Installs the latest version of the template package project.
    """
    # Check that the user really want to do this
    msg = 'Download Python package frtk to this directory (y/n)? '
    user_response = input(msg)
    if user_response != 'y':
        return None

    # Download ZIP archive of GitHub repository
    url = 'https://github.com/mx79/frtk/archive/master.git'
    r = requests.get(url)
    with open('temp.zip', 'wb') as f:
        f.write(r.content)

    # Extract ZIP file into calling directory
    with ZipFile('temp.zip', 'r') as repo_zip:
        repo_zip.extractall('.')

    # Clean up
    remove('temp.zip')

    return None
