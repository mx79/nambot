# Libraries
import json
import numpy as np
import matplotlib.pyplot as plt
from os.path import join
from collections import Counter
from frtk import clean_text
from imblearn.over_sampling import SMOTE
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split

# Classifiers
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import LinearSVC
from sklearn.linear_model import LogisticRegression
from sklearn.multiclass import OneVsRestClassifier

# Visualizers
from yellowbrick.classifier import ClassificationReport
from yellowbrick.classifier import ClassPredictionError
from sklearn.metrics import ConfusionMatrixDisplay, multilabel_confusion_matrix

# Metrics
from sklearn.metrics import cohen_kappa_score
from sklearn.metrics import hamming_loss
from sklearn.metrics import log_loss
from sklearn.metrics import zero_one_loss
from sklearn.metrics import matthews_corrcoef

# Path
pathdir = join("", "backend", "chucho")


def cr_viz():
    """Functions to display graphs, classification report.

    :return:
    """
    def cr(model, classes):
        visualizer = ClassificationReport(model, classes=classes, support=True)
        visualizer.fit(X_train, y_train)  # Fit the visualizer and the model
        visualizer.score(X_test, y_test)  # Evaluate the model on the test data
        plt.title(str(model))
        return visualizer.show()

    for name in classifiers:
        cr(name, intents)


def cpe_viz():
    """Class Prediction Error

    :return:
    """
    def cpe(model, classes):
        visualizer = ClassPredictionError(model, classes=classes)
        visualizer.fit(X_train, y_train)  # Fit the visualizer and the model
        visualizer.score(X_test, y_test)  # Evaluate the model on the test data
        plt.title(str(model))
        return visualizer.show()

    for name in classifiers:
        cpe(name, intents)


def multilabel_trixma_display():
    """Confusion Matrix for each intent

    :return:
    """

    def cm(model, classes):
        model.fit(X_train, y_train)
        y_pred = model.predict(X_test)
        trixma_list = multilabel_confusion_matrix(y_test, y_pred)
        f, axes = plt.subplots(5, 6, figsize=(30, 15))
        axes = axes.ravel()
        for i, (intent, trixma) in enumerate(zip(classes, trixma_list)):
            disp = ConfusionMatrixDisplay(trixma, display_labels=["True", "False"])
            disp.plot(ax=axes[i], values_format='.4g')
            if intent[:3] == "CAS" or "SOC":
                disp.ax_.set_title(f'{intent[4:].lower()}')
            else:
                disp.ax_.set_title(f'{intent.lower()}')
            disp.ax_.set_xlabel('')
            disp.ax_.set_ylabel('')
            disp.im_.colorbar.remove()
        plt.subplots_adjust(wspace=0.5, hspace=0.5)
        f.colorbar(disp.im_, ax=axes)
        plt.show()

    for name in classifiers:
        cm(name, intents)


def classifier_metrics():
    """Write a function to aggregate the metrics.

    :return:
    """

    def metrics(model):
        model.fit(X_train, y_train)
        y_pred = model.predict(X_test)
        try:
            y_prob = model.predict_proba(X_test)
            log_metric = log_loss(y_test, y_prob)
        except Exception:
            log_metric = 0
        c_k_s = cohen_kappa_score(y_test, y_pred)
        zero_met = zero_one_loss(y_test, y_pred)
        hl = hamming_loss(y_test, y_pred)
        mc = matthews_corrcoef(y_test, y_pred)
        print('cohen_kappa_score: {0:.3f}'.format(c_k_s))
        print('log_loss: {0:.3f}'.format(log_metric))
        print('zero_one_loss: {0:.3f}'.format(zero_met))
        print('hemming_loss: {0:.3f}'.format(hl))
        print('matthews_corrcoef: {0:.3f}'.format(mc))

    for name in classifiers:
        print(name)
        metrics(name)
        print("------------------------------------------------------")


# Sorting dataset infos
with open(join(pathdir, "data", "cas.json"), "r") as f:
    intent_json = json.load(f)
    f.close()
words = []
doc_X = []
for liste in intent_json.values():
    for sent in liste:
        tokens = clean_text(sent, no_accent=False)
        words.extend(tokens)
        doc_X.append(sent)
doc_y = [k for k, v in intent_json.items() for s in v]
intents = sorted(set(doc_y))
vocab = sorted(set(words))

# Bag of words
X = []
y = []
for idx, doc in enumerate(doc_X):
    bow = []
    text = clean_text(doc, no_accent=False)
    for word in vocab:
        bow.append(1) if word in text else bow.append(0)
    X.append(bow)
    y.append(doc_y[idx])
X = np.array(X)
y = np.array(y)

# Summarize distribution
encoder = LabelEncoder()
y = encoder.fit_transform(y)
counter = Counter(y)
plt.bar(counter.keys(), counter.values())
plt.title("Observation de la répartition des phrases par intention")
plt.xlabel("Intentions (avec les noms encodés)")
plt.ylabel("Nombre de phrases")
plt.show()
y = encoder.inverse_transform(y)

# Transform the dataset
oversample = SMOTE()
X, y = oversample.fit_resample(X, y)

# Train_test_split 80/20
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)

# List of classifiers
classifiers = [
    RandomForestClassifier(),
    LinearSVC(),
    LogisticRegression(random_state=0, multi_class='multinomial', solver='newton-cg')
]

# Launching multiclass classification with metrics to show
if __name__ == "__main__":
    # cr_viz()
    # cpe_viz()
    # multilabel_trixma_display()
    classifier_metrics()
