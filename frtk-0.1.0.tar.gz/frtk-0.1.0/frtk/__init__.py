import os

os.environ["TF_CPP_MIN_LOG_LEVEL"] = '2'

# Import of packages
import re
import json
import random
import string
import numpy as np
import pickle as pkl
import pkg_resources
import tensorflow as tf

# Import of classes and functions:
from keras import Sequential
from unidecode import unidecode
from typing import Any, AnyStr, List, Dict, Tuple
from keras.layers import Dense, Dropout
from sklearn.model_selection import train_test_split
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.multiclass import OneVsRestClassifier

# Preloading some data that we will use for some functions:
stopwords_data = json.load(pkg_resources.resource_stream(__name__, 'data/stopwords.json'))["fr"]
stem_data = json.load(pkg_resources.resource_stream(__name__, 'data/stemmer.json'))


def clean_text(
        s: str,
        no_stopword: bool = True,
        stem_text: bool = True,
        no_punctuation: bool = True,
        no_accent: bool = True,
        lowercase: bool = True,
) -> str:
    """The function that allows to clean a given text in depth by applying several layers of treatment.

    :param s: The sentence to clean
    :param no_stopword: The boolean that indicates if we must remove the stopwords in the text or not
    :param stem_text: The boolean that indicates if we must stem the text or not
    :param no_punctuation: The boolean that indicates if we must remove the punctuation the text or not
    :param no_accent: The boolean that indicates if we must remove the accents in the text or not
    :param lowercase: The boolean that indicates if we must set the text in lowercase or not
    :return: The sentence based on boolean values
    """
    if no_stopword:
        s = stopword(s)
    if stem_text:
        s = stem(s)
    if no_punctuation:
        s = remove_punctuation(s)
    if no_accent:
        s = remove_accent(s)
    if lowercase:
        s = s.lower()

    return s


def stopword(s: str) -> str:
    """The function that removes the stopwords contained in the input sentence.

    :param s: The sentence from which the stopwords must be removed
    :return: The sentence without stopwords
    """
    return " ".join(word for word in s.split() if word not in stopwords_data).strip()


def stem(s: str) -> str:
    """The function that stem the words of a sentence or a word.

    :param s: The sentence containing the words to stem or the word to stem
    :return: The stem sentence or the stem word
    """
    return " ".join(stem_data.get(word, word) for word in s.split()).strip()


def remove_punctuation(s: str) -> str:
    """The function that allows to remove punctuation in a sentence.

    :param s: The sentence from which the punctuation must be removed
    :return: The sentence without punctuation
    """
    return "".join(char for char in s if char not in string.punctuation).strip()


def remove_accent(s: str) -> str:
    """The function that allows you to remove the accents in a sentence.

    :param s: The sentence from which the accents must be removed
    :return: The sentence without accents
    """
    return unidecode(s)


class PrivateObjectError(Exception):
    """"""

    def __init__(self, class_name: str):
        super().__init__(f"You cannot use {class_name} object directly, use its subclasses instead.")


class ModelNotFoundError(Exception):
    """"""

    def __init__(self, class_name: str):
        super().__init__(f"No model was found for the object {class_name}.\n"
                         f"You should either train a model with `train` "
                         f"or load one with `from_model`.")


class _IntentClassifier:
    """"""

    def __init__(self):
        """Instantiation of an intention classification object based on Keras Sequential."""
        self.model: Any = None
        self.vocab: List = []
        self.classes: List = []

    def _sort(self, data_path: str) -> Tuple[List[str], List[str]]:
        """

        :param data_path:
        :return:
        """
        with open(data_path, "r") as f:
            intent_json = json.load(f)
            f.close()

        words = []
        doc_x = []
        for liste in intent_json.values():
            for sent in liste:
                tokens = clean_text(sent).split()
                words.extend(tokens)
                doc_x.append(sent)

        doc_y = [k for k, v in intent_json.items() for _ in v]
        self.vocab = sorted(set(words))
        self.classes = sorted(set(intent_json.keys()))

        return doc_x, doc_y

    def _bow_for_one_sentence(self, text: str) -> np.array:
        """The method that applies the bag of words technique.

        :param text: The sentence on which to apply the function
        :return: An array numpy with the number of occurrences of each word in the input sentence
        """
        bow = []
        sent = clean_text(text, no_accent=False)
        for word in self.vocab:
            bow.append(1) if word in sent else bow.append(0)

        return np.array([np.array(bow)])


class KerasIntentClassifier(_IntentClassifier):
    """"""

    def __init__(self):
        """Instantiation of an intention classification object based on Keras Sequential."""
        super().__init__()

    def train(self, data_path: str):
        """

        :param data_path:
        :return:
        """
        # First handler of the dataset
        doc_x, doc_y = self._sort(data_path)

        # Apply BOW (Bag Of Words) algorithm to the dataset
        x_train, y_train = self._bow(doc_x, doc_y)

        # Some parameters
        input_shape = (len(x_train[0]),)
        output_shape = len(y_train[0])

        # Deep Learning model
        model = Sequential()
        model.add(Dense(128, input_shape=input_shape, activation="relu"))
        model.add(Dropout(0.5))
        model.add(Dense(64, activation="relu"))
        model.add(Dropout(0.3))
        model.add(Dense(output_shape, activation="softmax"))
        adam = tf.keras.optimizers.legacy.Adam(learning_rate=0.01, decay=1e-6)
        model.compile(loss='categorical_crossentropy', optimizer=adam, metrics=["accuracy"])

        # Model fitting
        model.fit(x=x_train, y=y_train, epochs=200, verbose=1)

        # Store the model in object attributes
        self.model = model

    def get_intent(self, text: str) -> Dict:
        """The method that allows us to recover the intention of a given sentence.

        :param text: The sentence whose intention we want to detect
        :return: The intent, if any
        """
        res = self._pred(text, thresh=0.9)
        return 'out_of_scope' if len(res) == 0 else list(res.keys())[0]

    def _bow(self, doc_x: List[str], doc_y: List[str]) -> Tuple[np.ndarray, np.ndarray]:
        """

        :param doc_x:
        :param doc_y:
        :return:
        """
        training = []
        out_empty = [0] * len(self.classes)
        for idx, doc in enumerate(doc_x):
            bow = []
            text = clean_text(doc, no_accent=False)
            for word in self.vocab:
                bow.append(1) if word in text else bow.append(0)

            output_row = list(out_empty)
            output_row[self.classes.index(doc_y[idx])] = 1
            training.append([bow, output_row])

        random.shuffle(training)
        training = np.array(training, dtype=object)
        x_train = np.array(list(training[:, 0]))
        y_train = np.array(list(training[:, 1]))

        return x_train, y_train

    def _pred(self, val: str, thresh: float) -> Dict:
        """

        :param val:
        :param thresh:
        :return:
        """
        res = {}
        result = self.model.predict(self._bow_for_one_sentence(val))[0]
        y_pred = [[idx, res] for idx, res in enumerate(result) if res > thresh]
        y_pred.sort(key=lambda x: x[1], reverse=True)
        for r in y_pred:
            res[self.classes[r[0]]] = r[1]

        return res


class _SKLearnIntentClassifier(_IntentClassifier):
    """"""

    def __init__(self):
        """Instantiation of an intention classification object based on SKLearn models."""
        super().__init__()

    def from_model(self, model_path: str):
        """

        :param model_path:
        :return:
        """
        with open(model_path, "rb") as f:
            self.model = pkl.load(f)
            self.vocab = self.model.vocab_
            self.classes = self.model.classes_

    def train(self, data_path: str) -> OneVsRestClassifier:
        """

        :param data_path:
        :return:
        """
        # We create an instance of an estimator
        if isinstance(self, RandomForestIntentClassifier):
            estimator = RandomForestClassifier()
        elif isinstance(self, SVCIntentClassifier):
            estimator = SVC()
        elif isinstance(self, LogRegIntentClassifier):
            estimator = LogisticRegression(random_state=0, multi_class='multinomial', solver='newton-cg')
        else:
            raise PrivateObjectError(self.__class__.__name__)

        # One VS Rest classification to get better result
        ovr = OneVsRestClassifier(estimator)

        # First handler of the dataset
        doc_x, doc_y = self._sort(data_path)

        # Apply BOW (Bag Of Words) algorithm to the dataset
        x, y = self._bow(doc_x, doc_y)

        # Train_test_split 80/20
        x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.2)

        # Model fitting
        ovr.fit(x_train, y_train)

        # Set attribute `vocab` to ensure that the `from_model` method works properly
        setattr(ovr, 'vocab_', self.vocab)

        # Store the model in object attributes
        self.model = ovr

        return ovr

    def get_intent(self, text: str) -> str:
        """The method that allows us to recover the intention of a given sentence.

        :param text: The sentence whose intention we want to detect
        :return: The intent, if any
        """
        if self.model:
            return self.model.predict(self._bow_for_one_sentence(text))[0]
        else:
            raise ModelNotFoundError(self.__class__.__name__)

    def _bow(self, doc_x: List[str], doc_y: List[str]) -> Tuple[np.ndarray, np.ndarray]:
        """

        :param doc_x:
        :param doc_y:
        :return:
        """
        x = []
        y = []
        for idx, doc in enumerate(doc_x):
            bow = []
            text = clean_text(doc, no_accent=False)
            for word in self.vocab:
                bow.append(1) if word in text else bow.append(0)
            x.append(bow)
            y.append(doc_y[idx])

        return np.asarray(x), np.asarray(y)


class SVCIntentClassifier(_SKLearnIntentClassifier):
    """"""

    def __init__(self):
        """Instantiation of an intention classification object based on SVC."""
        super().__init__()


class RandomForestIntentClassifier(_SKLearnIntentClassifier):
    """"""

    def __init__(self):
        """Instantiation of an intention classification object based on Random Forest."""
        super().__init__()


class LogRegIntentClassifier(_SKLearnIntentClassifier):
    """"""

    def __init__(self):
        """Intention classification object based on Multinomial Logistic Regression."""
        super().__init__()


class RegexEntityExtractor:
    """RegexEntityExtractor object with a dictionary of entities and patterns."""

    def __init__(self, regex_path: str):
        """Instantiation of the RegexEntityExtractor object with a dictionary of entities and patterns.

        :param regex_path: The file that contains the dictionary with entities and their corresponding pattern as regex
        """
        with open(regex_path) as f:
            regex_dict = json.load(f)

        self.regex_dict = regex_dict

    def get_entity(self, text: str) -> Dict[str, AnyStr | List[AnyStr]]:
        """The method that returns a match dictionary based on the entities found in the input sentence.

        :param text: The text or sentence that we pass to the extractor
        :return: A match dictionary based on the entities found
        """
        res = {}
        pattern_list = []
        cleaned_text = clean_text(text, stem_text=False, no_accent=False, lowercase=False)

        for key, value in self.regex_dict.items():
            for pattern in value:
                if m := re.search(pattern, cleaned_text):
                    pattern_list.append(m.group())
                    pattern_list = sorted(set(pattern_list))
                    res[key] = pattern_list if len(pattern_list) > 1 else m.group()
            pattern_list = []

        return res
