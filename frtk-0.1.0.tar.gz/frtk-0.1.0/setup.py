from os.path import abspath, dirname, join
from setuptools import setup, find_packages

# Get key package details from frtk/__version__.py
about = {}
here = dirname(abspath(__file__))
with open(join(here, 'frtk', '__version__.py')) as f:
    exec(f.read(), about)

# Load the README file and use it as the long_description
with open('README.md', 'r') as f:
    readme = f.read()

setup(
    name=about['__title__'],
    description=about['__description__'],
    long_description=readme,
    long_description_content_type='text/markdown',
    version=about['__version__'],
    author=about['__author__'],
    author_email=about['__author_email__'],
    url=about['__url__'],
    packages=find_packages(),
    include_package_data=True,
    python_requires=">=3.8",
    install_requires=[
        "imblearn",
        "keras",
        "matplotlib",
        "numpy",
        "scikit-learn",
        "tensorflow",
        "yellowbrick",
        "unidecode"
    ],
    package_dir={'frtk': 'frtk'},
    package_data={
        'frtk': ['data/*.json'],
    },
    license=about['__license__'],
    zip_safe=False,
    entry_points={
        'console_scripts': ['frtk=frtk.entry_points:main'],
    },
    classifiers=[
        'Programming Language :: Python :: 3.8',
        'Intended Audience :: Developers',
        'Operating System :: OS Independent',
    ],
    keywords='Natural Language Processing common methods'
)
